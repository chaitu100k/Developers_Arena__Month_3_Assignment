
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt
import seaborn as sns

# Load dataset
df = pd.read_csv("Retail_Customers_Full.csv")
df_features = df.drop(['CustomerID'], axis=1)
df_features = pd.get_dummies(df_features, drop_first=True)

# Scale features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(df_features)

# K-Means clustering
kmeans = KMeans(n_clusters=4, random_state=42)
clusters = kmeans.fit_predict(X_scaled)
df['Cluster'] = clusters

# Save cluster assignments
df[['CustomerID','Cluster']].to_csv("CustomerClusters.csv", index=False)

# Evaluate clustering quality
score = silhouette_score(X_scaled, clusters)
print("Silhouette Score:", score)

# PCA for visualization
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)

plt.figure(figsize=(8,6))
sns.scatterplot(x=X_pca[:,0], y=X_pca[:,1], hue=df['Cluster'], palette='Set2')
plt.title("Customer Segments (PCA Reduced)")
plt.xlabel("PC1")
plt.ylabel("PC2")
plt.savefig("cluster_visualization.png")
plt.show()
