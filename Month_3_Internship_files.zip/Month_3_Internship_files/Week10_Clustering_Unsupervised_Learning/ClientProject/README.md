
# Week 10 - Client Project (Customer Segmentation)
This folder contains the client project script for customer segmentation.

Files:
- week10_customer_segmentation.py : Full segmentation script using full dataset.
- Retail_Customers_Full.csv : Full synthetic dataset (~7k rows).
- CustomerClusters.csv : Output file with cluster assignments.
- cluster_visualization.png : PCA scatter plot of clusters.
- model_evaluation_report.pdf : Detailed project report.
- README.md : Instructions to run.

Run:
    pip install -r requirements.txt
    python week10_customer_segmentation.py
