
# Week 10 - Hands-On
This folder contains the Hands-On script for K-Means clustering and PCA dimensionality reduction.

Files:
- week10_kmeans_pca.py : Script for hands-on clustering exercise.
- Retail_Customers_Sample.csv : Small sample dataset (~50 rows).
- hands_on_report.pdf : Detailed hands-on report (included).
- README.md : Instructions to run.

Run:
    pip install -r requirements.txt
    python week10_kmeans_pca.py
