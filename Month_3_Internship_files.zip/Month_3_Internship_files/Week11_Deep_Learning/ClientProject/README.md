
# Week 11 - Client Project (MNIST Image Classification)
This folder contains the client project script for MNIST digit classification.

Files:
- week11_mnist_classification.py : Script to train NN on MNIST dataset.
- mnist_model.h5 : Trained model (generated after running the script).
- README.md : Instructions to run.

Run:
    pip install -r requirements.txt
    python week11_mnist_classification.py
