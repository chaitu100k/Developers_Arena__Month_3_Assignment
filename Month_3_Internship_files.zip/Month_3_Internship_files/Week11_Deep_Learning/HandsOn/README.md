
# Week 11 - Hands-On
This folder contains the Hands-On script for a simple Neural Network on synthetic data.

Files:
- week11_hands_on_nn.py : Script for hands-on exercise.
- README.md : Instructions to run.

Run:
    pip install -r requirements.txt
    python week11_hands_on_nn.py
