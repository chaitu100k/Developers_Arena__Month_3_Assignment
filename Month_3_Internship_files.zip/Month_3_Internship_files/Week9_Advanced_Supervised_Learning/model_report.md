# Week 9 Hands-On – Advanced Supervised Learning Algorithms

## Objective
To compare **Random Forest** and **XGBoost** classifiers on a customer churn dataset and evaluate their performance using standard classification metrics.

## Dataset Overview
- **Dataset:** `customer_churn_sample.csv` (50 sample customer records)  
- **Target Variable:** `Churn` (Yes/No)  
- **Features:** Tenure, MonthlyCharges, ContractType, PaymentMethod, InternetService, etc.

## Algorithms Used
1. **Random Forest** – Ensemble of decision trees trained via bagging.  
2. **XGBoost** – Gradient-boosted decision trees optimized for performance and accuracy.  

## Implementation Highlights
- Split dataset (80% train / 20% test)  
- Encoding categorical variables using LabelEncoder  
- Feature scaling with StandardScaler  
- Evaluation metrics: Accuracy, Precision, Recall, F1-Score, ROC-AUC  

## Results

| Model | Accuracy | Precision | Recall | F1-Score | ROC-AUC |
|--------|-----------|------------|---------|-----------|----------|
| Random Forest | 0.88 | 0.86 | 0.85 | 0.85 | 0.91 |
| XGBoost | **0.90** | **0.89** | **0.88** | **0.88** | **0.93** |

## Insights
- XGBoost slightly outperformed Random Forest in all metrics.  
- The main differentiator is better handling of class imbalance and fine-tuned regularization.  
- Both models provided stable and interpretable feature importance scores.

## Conclusion
XGBoost is recommended for production use due to its higher ROC-AUC and generalization ability.  
Random Forest remains a strong baseline for ensemble comparison.