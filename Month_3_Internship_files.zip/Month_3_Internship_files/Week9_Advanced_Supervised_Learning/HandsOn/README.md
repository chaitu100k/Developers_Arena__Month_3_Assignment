
# Week 9 - Hands-On
This folder contains the hands-on script comparing Random Forest and XGBoost on a sample churn dataset.

Files:
- week9_randomforest_xgboost.py : Run this file to train and compare models on the sample dataset.
- customer_churn_sample.csv : Small demo dataset (50 rows) for quick runs.
- model_report.pdf : Detailed model report (included).
- README.md : This file.

Run:
    pip install -r requirements.txt
    python week9_randomforest_xgboost.py
