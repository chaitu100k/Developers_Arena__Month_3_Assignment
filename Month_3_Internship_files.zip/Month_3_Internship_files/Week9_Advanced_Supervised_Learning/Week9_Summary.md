# Week 9 Summary – Advanced Supervised Learning Algorithms

## Topics Covered
- **Random Forest:** Bagging-based ensemble method using multiple decision trees.  
- **Gradient Boosting:** Sequential model building minimizing residual errors.  
- **XGBoost:** Optimized boosting framework with regularization and tree pruning.  
- **SVM (Support Vector Machine):** Classification using optimal hyperplanes.  

## Key Learnings
- Ensemble methods reduce overfitting and improve generalization.  
- Boosting algorithms (especially XGBoost) often outperform single models.  
- Model evaluation requires both statistical and business interpretation.  

## Submission Checklist
✅ `week9_randomforest_xgboost.py`  
✅ `week9_clientproject_churn_xgboost.py`  
✅ PDF Reports & Markdown summaries  

## Conclusion
Week 9 provided a strong understanding of ensemble-based supervised learning and its real-world applications in customer retention and business analytics.