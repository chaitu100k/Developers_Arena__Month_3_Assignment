# Client Project – Predicting Customer Churn Using XGBoost

## Objective
To build an accurate churn prediction model for a telecom company using advanced ensemble learning (XGBoost).

## Dataset Details
- **Source:** Kaggle – Telco Customer Churn (7,043 rows)  
- **Target:** `Churn` (binary)  
- **Key Predictors:** tenure, MonthlyCharges, Contract, InternetService, PaymentMethod  

## Preprocessing
- Removed customer IDs  
- Encoded categorical variables (LabelEncoder)  
- Imputed missing TotalCharges values  
- Standardized numerical features  
- Split 80/20 for training/testing  

## Model Development
Used **XGBoostClassifier** with parameter tuning:  
`max_depth=6, learning_rate=0.1, n_estimators=200, subsample=0.8, colsample_bytree=0.8`  

## Evaluation Metrics

| Metric | Value |
|---------|--------|
| Accuracy | **0.82** |
| Precision | 0.80 |
| Recall | 0.78 |
| F1-Score | 0.79 |
| ROC-AUC | **0.87** |

## Key Findings
- **Tenure**, **Contract Type**, and **Monthly Charges** are top churn predictors.  
- Long-term contracts correlate with reduced churn risk.  
- Model confusion matrix shows balanced classification with minor false positives.  

## Business Insights
- Offer loyalty discounts for short-tenure customers.  
- Improve payment flexibility for electronic check users.  
- Focus marketing on fiber-optic internet users with higher churn tendency.  

## Conclusion
XGBoost delivers strong predictive performance for churn detection and can assist the telecom firm in proactive retention strategies.