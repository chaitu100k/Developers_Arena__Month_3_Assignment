
# Week 9 - Client Project (Telco Churn Prediction)
This folder contains the client project script using XGBoost. The script will try to download the full Telco dataset automatically
from a GitHub mirror if 'Telco-Customer-Churn.csv' is not present.

Files:
- week9_clientproject_churn_xgboost.py : Main project script (auto-downloads dataset when run).
- model_evaluation_report.pdf : Detailed model evaluation report (included).
- README.md : This file.

Run:
    pip install -r requirements.txt
    python week9_clientproject_churn_xgboost.py
