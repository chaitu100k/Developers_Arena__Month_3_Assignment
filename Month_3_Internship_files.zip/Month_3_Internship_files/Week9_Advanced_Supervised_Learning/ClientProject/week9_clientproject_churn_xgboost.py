# week9_clientproject_churn_xgboost.py
"""
Client Project: Telco Customer Churn Prediction using XGBoost.
This script will automatically download the full Telco dataset if 'Telco-Customer-Churn.csv' is not present.
Usage:
    python week9_clientproject_churn_xgboost.py
"""
import os
import pandas as pd
import numpy as np

def download_dataset(path="Telco-Customer-Churn.csv"):
    if os.path.exists(path):
        print(f"Dataset '{path}' already present.")
        return path
    try:
        # Raw GitHub mirror of the Kaggle dataset
        url = "https://raw.githubusercontent.com/blastchar/telco-customer-churn/master/Telco-Customer-Churn.csv"
        print("Downloading dataset from:", url)
        import requests
        r = requests.get(url, timeout=30)
        if r.status_code == 200:
            with open(path, "wb") as f:
                f.write(r.content)
            print("Downloaded dataset to", path)
            return path
        else:
            raise Exception(f"Failed to download, status code: {r.status_code}")
    except Exception as e:
        print("Automatic download failed:", e)
        print("Please download 'Telco-Customer-Churn.csv' manually from Kaggle and place it in the script folder.")
        raise

def preprocess(df):
    df = df.copy()
    if 'customerID' in df.columns:
        df = df.drop(['customerID'], axis=1)
    df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce')
    df = df.dropna()
    # Encode categorical variables using get_dummies for better handling
    df = pd.get_dummies(df, drop_first=True)
    X = df.drop('Churn_Yes', axis=1)
    y = df['Churn_Yes']
    return X, y

def train_and_evaluate(X, y):
    from sklearn.model_selection import train_test_split, GridSearchCV
    from sklearn.preprocessing import StandardScaler
    from xgboost import XGBClassifier
    from sklearn.metrics import accuracy_score, roc_auc_score, classification_report, confusion_matrix
    import joblib, os

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X_train)
    X_test = scaler.transform(X_test)

    xgb = XGBClassifier(
        n_estimators=300,
        learning_rate=0.05,
        max_depth=6,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        eval_metric='logloss',
        use_label_encoder=False
    )
    xgb.fit(X_train, y_train, early_stopping_rounds=10, eval_set=[(X_test, y_test)], verbose=False)
    y_pred = xgb.predict(X_test)

    print("Accuracy:", accuracy_score(y_test, y_pred))
    print("ROC-AUC:", roc_auc_score(y_test, y_pred))
    print("\\nClassification Report:\\n", classification_report(y_test, y_pred))
    print("\\nConfusion Matrix:\\n", confusion_matrix(y_test, y_pred))

    os.makedirs("models", exist_ok=True)
    joblib.dump(xgb, "models/xgboost_churn_model.pkl")
    joblib.dump(scaler, "models/scaler.pkl")
    print("\\nSaved model and scaler to ./models/")

    # Feature importance
    try:
        importances = xgb.get_booster().get_score(importance_type='gain')
        sorted_imp = sorted(importances.items(), key=lambda x: x[1], reverse=True)[:15]
        print("\\nTop 15 features by gain:")
        for f, imp in sorted_imp:
            print(f, imp)
    except Exception as e:
        print("Could not extract feature importances:", e)

def main():
    path = "Telco-Customer-Churn.csv"
    try:
        download_dataset(path)
    except Exception:
        return
    df = pd.read_csv(path)
    X, y = preprocess(df)
    train_and_evaluate(X, y)

if __name__ == "__main__":
    main()
